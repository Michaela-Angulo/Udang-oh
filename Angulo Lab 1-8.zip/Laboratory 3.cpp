#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<ctype.h>
#include<cstring>
#include<bits/stdc++.h>
#include <algorithm> 
#include<string>
#include <windows.h>
#include <sstream>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

void Capitalize()
{
	int i;
	string a;
	cout<<"Enter a string: ";
	getline(cin,a);
	for(i=0;a[i]!= '\0' ;++i)
		{
			if(i==0)
				{
					if(islower(a[i]))
					a[i]=toupper(a[i]);
				}
			else
				{
					if(a[i]!=' ')
						{		
							if(isupper(a[i]))
							a[i]=tolower(a[i]);
						}
			else
				{
					i++;
					if(islower(a[i]))
					a[i]=toupper(a[i]);
				}
		}
		}
	cout<<"New string is: "<<a;
	getch();
}

void Palindrome()
{
	int size, flag = 0;	
	string string1, string2;
	cout<<"Enter a word or phrase: ";
    getline(cin,string1);
	
    string2 = string1;
    string2.erase(remove(string2.begin(), string2.end(), ' '), string2.end()); 

    size = string2.length();
    	
	transform(string2.begin(), string2.end(), string2.begin(), ::tolower); 
	
    
	for(int i=0;i < size ;i++){
		
        if(string2[i] != string2[size-i-1]){
        flag = 1;}}
            
    if (flag == 1) {
        cout << string1 << " is not a palindrome" << endl; }    
    	else if (flag == 0) {cout << string1 << " is a palindrome" << endl; }
}

void StringCompare()
{
	char string3[100], string4[100];
	int checker;
	cout<<"Enter the first string: ";
	cin.getline(string3,100);  
	
	cout<<"Enter the second string: ";
	cin.getline(string4,100); 
	
	checker = strcmp(string3, string4);
	if(checker == 0)
	{cout<<"Equal";}
	else if(checker == -1)
	{cout<<"Negative";}
	else if(checker == 1)
	{cout<<"Positive";}
}

char* stringreverse(char *string)
{
	char *rev;
	rev = new char;
	int i, counter(0);
	
	for (i = 0; string[i]!= '\0'; i++)
	{
		
		counter++;
	}
	for (i = 0;string[counter]>= 0; i++)
	{
		rev[i] = string[--counter];
	}
	
	rev[i] = '\0';
	return rev;
}

void StringConcatenation()
{
	char s1[100], s2[100];
    string s3;
    cout << "Enter string 1: ";
    cin.getline(s1, 100);
    cout << "Enter string 2: ";
    cin.getline(s2, 100);
    
	s3 = strcat(s1, s2);
    cout << "new value for string 1: "<< s3 << endl;
}

void StringCopy()
{
	char s3[100], s4[100];
    cout << "Enter string 1: ";
    cin.getline(s3, 100);
    cout << "Enter string 2: ";
    cin.getline(s4, 100);
    
	strcpy(s3, s4);
    cout << "new value for string 1: "<< s3 << endl;
}

int main()
{
	{
	menu:
	system("cls");
	gotoxy(18,3);cout<<" ____________________________________________"<<endl;
	gotoxy(18,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(18,5);cout<<"| |                                        | |"<<endl;
	gotoxy(18,6);cout<<"| |                                        | |"<<endl;
	gotoxy(18,7);cout<<"| |         [Laboratory 3 Compilation]     | |"<<endl;
	gotoxy(18,8);cout<<"| |                                        | |"<<endl;
	gotoxy(18,9);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(18,10);cout<<"| |________________________________________| |"<<endl;
	gotoxy(18,11);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	gotoxy (9, 13);cout<<"  ____________________________________________________________"<<endl;
	gotoxy (9, 14);cout<<" |  ________________________________________________________  |"<<endl;
	gotoxy (9, 15);cout<<" | |                                                        | |"<<endl;
	gotoxy (9, 16);cout<<" | |Press [1] for Capitalizing the first letter of the word | |"<<endl;
	gotoxy (9, 17);cout<<" | |Press [2] for Palindrome Checker                        | |"<<endl;
	gotoxy (9, 18);cout<<" | |Press [3] for String Compare                            | |"<<endl;
	gotoxy (9, 19);cout<<" | |Press [4] for Reversed Words                            | |"<<endl;
	gotoxy (9, 20);cout<<" | |Press [5] for String Concatenation                      | |"<<endl;
	gotoxy (9, 21);cout<<" | |Press [6] for String Copy                               | |"<<endl;
	gotoxy (9, 22);cout<<" | |                                                        | |"<<endl;
	gotoxy (9, 23);cout<<" | |Enter your choice:                                      | |"<<endl;
	gotoxy (9, 24);cout<<" | |________________________________________________________| |"<<endl;
	gotoxy (9, 25);cout<<" |____________________________________________________________|"<<endl;
	gotoxy (32, 23);int choice;
	cin>>choice;
	cin.ignore();
	system("cls");
	
	if (choice == 1)
	{
		Capitalize();
		cout<<endl;
		system("pause");
		goto menu;
	}
	else if (choice == 2)
	{
		Palindrome();
		cout<<endl;
		system("pause");
		goto menu;
	}
	else if (choice == 3)
	{
		StringCompare();
		cout<<endl;
		system("pause");
		goto menu;
	}
	else if (choice == 4)
	{
		char string[100];
		cout<<"Enter a string: ";
		cin.getline(string, 100);
		cout<<"Reversed form of the string: "<<stringreverse(string)<<endl;
		system("pause");
		goto menu;
	}
	else if (choice == 5)
	{
		StringConcatenation();
		cout<<endl;
		system("pause");
		goto menu;
	}
	else if (choice == 6)
	{
		StringCopy();
		cout<<endl;
		system("pause");
		goto menu;
	}
	else
	{
		cout<<"Invalid Input!"<<endl;
		system("pause");
		goto menu;
	}
	return 0;
}
}
