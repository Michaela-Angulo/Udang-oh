#include<iostream>
#include<cstring>
#include <windows.h>
#include <sstream>
using namespace std;
int stringcompare(char *string1, char *string2);
void stringcat(char *string3, char *string4);
void stringcopy(char *string5, char *string6);
int stringlength(char *string7);
char* stringreverse(char*string8);
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int main ()
{
	menu:
	system("cls");
	gotoxy(18,3);cout<<" ____________________________________________"<<endl;
	gotoxy(18,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(18,5);cout<<"| |                                        | |"<<endl;
	gotoxy(18,6);cout<<"| |                                        | |"<<endl;
	gotoxy(18,7);cout<<"| |         [Laboratory 4 Compilation]     | |"<<endl;
	gotoxy(18,8);cout<<"| |                                        | |"<<endl;
	gotoxy(18,9);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(18,10);cout<<"| |________________________________________| |"<<endl;
	gotoxy(18,11);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	gotoxy (9, 13);cout<<"  ____________________________________________________________"<<endl;
	gotoxy (9, 14);cout<<" |  ________________________________________________________  |"<<endl;
	gotoxy (9, 15);cout<<" | |                                                        | |"<<endl;
	gotoxy (9, 16);cout<<" | |Press [1] for String Compare                            | |"<<endl;
	gotoxy (9, 17);cout<<" | |Press [2] for String Concatenation                      | |"<<endl;
	gotoxy (9, 18);cout<<" | |Press [3] for String Copy                               | |"<<endl;
	gotoxy (9, 19);cout<<" | |Press [4] for String Length                             | |"<<endl;
	gotoxy (9, 20);cout<<" | |Press [5] for String Reversed                           | |"<<endl;
	gotoxy (9, 21);cout<<" | |                                                        | |"<<endl;
	gotoxy (9, 22);cout<<" | |Enter your choice:                                      | |"<<endl;
	gotoxy (9, 23);cout<<" | |________________________________________________________| |"<<endl;
	gotoxy (9, 24);cout<<" |____________________________________________________________|"<<endl;
	gotoxy (32, 22);int choice;
	cin>>choice;
	cin.ignore(); 
	
	if (choice == 1)
	{
		system("cls");
		char string1[100];
		char string2[100];
		cout<<"Enter the first string: ";
		cin.getline(string1, 100);
		cout<<"Enter the second string: ";
		cin.getline(string2, 100);
 	
		cout<<"String Compare Value: "<<stringcompare(string1,string2)<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 2)
	{
		system("cls");
		char string3[100];
		char string4[100];
		cout<<"Enter the first string: ";
		cin.getline(string3, 100);
		cout<<"Enter the second string: ";
		cin.getline(string4, 100);
	
		stringcat(string3,string4);
		cout<<"New String: "<<string3<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 3)
	{
		system("cls");
		char string5[100];
		char string6[100];
		cout<<"Enter a string to copy: ";
		cin.getline(string6, 100);
		stringcopy(string5,string6);
		cout<<"string 1: "<<string5<<endl;
		cout<<"string 2: "<<string6<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 4)
	{
		system("cls");
		char string7[100];
		cout<<"Enter a string: ";
		cin.getline(string7, 100);
		cout<<"Length of the string: "<<stringlength(string7)<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 5)
	{
		system("cls");
		char string8[100];
		cout<<"Enter a string: ";
		cin.getline(string8, 100);
		cout<<"Reversed form of the string: "<<stringreverse(string8)<<endl;
		system("pause");
		goto menu;
	}
	
	else
	{
		cout<<"Invalid Input!"<<endl;
		system("pause");
		goto menu;
	}
	
	return 0;
}

int stringcompare(char *string1, char *string2)
{
	for (;*string1 == *string2; *string1++,*string2++)
	{
		if(*string1 == '\0' && *string2 == '\0')
		{
			return 0;
		}
		return *string1-*string2;
	}
}

void stringcat(char *string3, char *string4)
{
	while (*string3++);
	string3--;
	while(*string3++=*string4++);
	

}

void stringcopy(char *string5, char *string6)
{
	while (*string6 != '\0')
	{
		*string5 = *string6;
		string5++;
		string6++;
	}
	
	*string5 = '\0';
}

int stringlength(char *string7)
{
	int i;
	for(i = 0;string7[i]!='\0'; i++);
	return i;
}

char* stringreverse(char *string8)
{
	char *rev;
	rev = new char;
	int i, counter(0);
	
	for (i = 0; string8[i]!= '\0'; i++)
	{
		
		counter++;
	}
	for (i = 0;string8[counter]>= 0; i++)
	{
		rev[i] = string8[--counter];
	}
	
	rev[i] = '\0';
	return rev;
}
