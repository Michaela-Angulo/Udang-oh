#include<iostream>
#include <windows.h>
#include <sstream>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
//Certificate of deposit account structure
struct CDAccount{
	double balance;
	double interestRate;
	int term;
};

CDAccount doubleInterest(CDAccount oldAccount);

void accountBalance(CDAccount& _account);

int main()
{
	gotoxy(18,3);cout<<" ____________________________________________"<<endl;
	gotoxy(18,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(18,5);cout<<"| |                                        | |"<<endl;
	gotoxy(18,6);cout<<"| |                                        | |"<<endl;
	gotoxy(18,7);cout<<"| |             [Laboratory 8]             | |"<<endl;
	gotoxy(18,8);cout<<"| |     Certificate of Deposit Account     | |"<<endl;
	gotoxy(18,9);cout<<"| |                                        | |"<<endl;
	gotoxy(18,10);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(18,11);cout<<"| |________________________________________| |"<<endl;
	gotoxy(18,12);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	system("pause");
	system("cls");
	CDAccount account;
	string option;
	
	cout<<"Enter account balance: PhP ";
	cin>>account.balance;
	cout<<"Enter account interest: ";
	cin>>account.interestRate;
	cout<<"Enter the number of months until maturity: ";
	cin>>account.term;
	
	accountBalance(account);
	
	cout<<"\nOld Account \n"
		<<"when your CD matures in \n"
		<<account.term<<" months, \n"
		<<"it will have a balance of Php "
		<<account.balance<<endl;
		
	CDAccount accountNew;
	accountNew = doubleInterest(account);
	
	accountBalance(accountNew);
	
	cout<<"\nNew Account \n"
		<<"when your CD matures in "
		<<accountNew.term<<" months, \n"
		<<"it will have a balance of Php "
		<<accountNew.balance<<endl;

	return 0;
}

void accountBalance(CDAccount& _account)
{
	double rateFraction, interest;
	rateFraction = _account.interestRate/100.0;
	interest = _account.balance*(rateFraction*(_account.term/12.0));
	_account.balance = _account.balance + interest;
}

CDAccount doubleInterest(CDAccount oldAccount)
{
	CDAccount temp;
	temp = oldAccount;
	temp.interestRate = 2*oldAccount.interestRate;
	return temp;
}

