#include <iostream>
#include <string>
#include <ctype.h>
#include <windows.h>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

bool Palindrome(string s)
{
  int i,j;
  i=0;
  j=s.length()-1;
  
  while(i<j)
  {
    
    while(i<j && isalnum(s[i])==0)
      i++;
    while(i<j && isalnum(s[j])==0)
      j--;

   if(toupper(s[i])!=toupper(s[j]))
    {
     return false;
    }
   else
   {
    i++;
    j--;
   }

  }
  return true;
}

int main() {
	main:
	gotoxy(20,3);cout<<" ____________________________________________"<<endl;
	gotoxy(20,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(20,5);cout<<"| |                                        | |"<<endl;
	gotoxy(20,6);cout<<"| |                                        | |"<<endl;
	gotoxy(20,7);cout<<"| |     [PALINDROME OR NOT PALINDROME]     | |"<<endl;
	gotoxy(20,8);cout<<"| |                                        | |"<<endl;
	gotoxy(20,9);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(20,10);cout<<"| |________________________________________| |"<<endl;
	gotoxy(20,11);cout<<"|____________________________________________|"<<endl;
	gotoxy(20,12);cout<<""<<endl;
	
	gotoxy (19, 13);cout<<"  _____________________________________________"<<endl;
	gotoxy (19, 14);cout<<" |  _________________________________________  |"<<endl;
	gotoxy (19, 15);cout<<" | |                                         | |"<<endl;
	gotoxy (19, 16);cout<<" | | Enter a valid word, phrase, or numbers: | |"<<endl;
	gotoxy (19, 17);cout<<" | |                                         | |"<<endl;
	gotoxy (19, 18);cout<<" | |                                         | |"<<endl;
	gotoxy (19, 19);cout<<" | |                                         | |"<<endl;
	gotoxy (19, 20);cout<<" | |                                         | |"<<endl;;
	gotoxy (19, 21);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (19, 22);cout<<" |_____________________________________________|"<<endl;
	cout<<""<<endl;
	
  string s;
  gotoxy(38,18);getline(cin,s);
  int ans = Palindrome(s);

  if ( ans == 1 ) 
  {
   gotoxy(34,20);cout<<"It is a palindrome."<<endl;
   cout<<""<<endl;
   cout<<""<<endl;

  }
  else 
  {
   gotoxy(32,20);cout<<"It is not a palindrome."<<endl;
   cout<<""<<endl;
   cout<<""<<endl;

  }	
 	gotoxy (67, 7);cout<<"  ___________________________"<<endl;
	gotoxy (67, 8);cout<<" |  _______________________  |"<<endl;
	gotoxy (67, 9);cout<<" | |                       | |"<<endl;
	gotoxy (67, 10);cout<<" | |Press [1] to try again.| |"<<endl;
	gotoxy (67, 11);cout<<" | |Press [0] to exit.     | |"<<endl;
	gotoxy (67, 12);cout<<" | |Choice:                | |"<<endl;
	gotoxy (67, 13);cout<<" | |_______________________| |"<<endl;
	gotoxy (67, 14);cout<<" |___________________________|"<<endl;
					
		int y; 
		gotoxy(80,12);cin>>y;
		if (y == 1) {
		system ("cls");
		goto main;
		}
		else if ( y == 0) {
		system ("cls");
		}
}
