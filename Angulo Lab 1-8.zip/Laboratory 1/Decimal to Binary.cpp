#include <iostream>
#include <windows.h>
#include<cstring>
#include <sstream>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int main()  
{  
{
main:
int a[10], n, i;    
	gotoxy(10,3);cout<<" ____________________________________________"<<endl;
	gotoxy(10,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(10,5);cout<<"| |                                        | |"<<endl;
	gotoxy(10,6);cout<<"| |                                        | |"<<endl;
	gotoxy(10,7);cout<<"| |     [CONVERTING DECIMAL TO BINARY]     | |"<<endl;
	gotoxy(10,8);cout<<"| |                                        | |"<<endl;
	gotoxy(10,9);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(10,10);cout<<"| |________________________________________| |"<<endl;
	gotoxy(10,11);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	gotoxy (9, 13);cout<<"  ____________________________________________"<<endl;
	gotoxy (9, 14);cout<<" |  ________________________________________  |"<<endl;
	gotoxy (9, 15);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 16);cout<<" | |      Enter a number to convert:        | |"<<endl;
	gotoxy (9, 17);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 18);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 19);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 20);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 21);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 22);cout<<" | |                                        | |"<<endl;
	gotoxy (9, 23);cout<<" | |________________________________________| |"<<endl;
	gotoxy (9, 24);cout<<" |____________________________________________|"<<endl;
	gotoxy(30,18);cin>>n;    


if ( n == 0) {
	gotoxy(27,22);cout<<"0"<<endl;
}
else if ( n < 0 ) {
	gotoxy(25,22);
	cout<<"Invalid input!"<<endl;
}
for(i=0; n>0; i++)    
{    
a[i]=n%2;    
n= n/2;  
}    
gotoxy(19,20);cout<<"Binary of the given number: "<<endl;

gotoxy(27,22);   
for(i=i-1 ;i>=0 ;i--)    
{    
cout<<a[i];
} 
cout<<endl;  
}
	option:
	gotoxy (57, 7);cout<<"  ___________________________"<<endl;
	gotoxy (57, 8);cout<<" |  _______________________  |"<<endl;
	gotoxy (57, 9);cout<<" | |                       | |"<<endl;
	gotoxy (57, 10);cout<<" | |Press [1] to try again.| |"<<endl;
	gotoxy (57, 11);cout<<" | |Press [0] to exit.     | |"<<endl;
	gotoxy (57, 12);cout<<" | |Choice:                | |"<<endl;
	gotoxy (57, 13);cout<<" | |_______________________| |"<<endl;
	gotoxy (57, 14);cout<<" |___________________________|"<<endl;
					
		string y; 
		gotoxy(69,12);getline(cin, y);
		if (y == "1") {
		system ("cls");
		goto main;
		}
		else if ( y == "0") {
		system ("cls");
		}
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
}  
