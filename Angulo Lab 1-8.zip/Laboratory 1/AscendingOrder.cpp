#include <iostream>
#include <windows.h>
#include<cstring>
#include <sstream>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
int main()
{
	main:
		
	cout<<" ______________________________________________________________________________________________"<<endl;
	cout<<"|----------------------------------------------------------------------------------------------|"<<endl;
	cout<<"|[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[]                                                                                          []|"<<endl;
	cout<<"|[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]|"<<endl;
	cout<<"|----------------------------------------------------------------------------------------------|"<<endl;
	cout<<"|______________________________________________________________________________________________|"<<endl;

	
	gotoxy (24, 3); cout<<" ____________________________________________"<<endl;
	gotoxy (24, 4); cout<<"|  ________________________________________  |"<<endl;
	gotoxy (24, 5); cout<<"| |                                        | |"<<endl;
	gotoxy (24, 6); cout<<"| |                                        | |"<<endl;
	gotoxy (24, 7); cout<<"| |            [ASCENDING ORDER]           | |"<<endl;
	gotoxy (24, 8); cout<<"| |                                        | |"<<endl;
	gotoxy (24, 9); cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy (24, 10); cout<<"| |________________________________________| |"<<endl;
	gotoxy (24, 11); cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	gotoxy (10, 14); cout<<"Enter 10 integer numbers: "<<endl;
	cout<<endl;
	
	gotoxy (10, 15);cout<<" ______________________"<<endl;
	gotoxy (10, 16);cout<<"|  __________________  |"<<endl;
	gotoxy (10, 17);cout<<"| |                  | |"<<endl;
	gotoxy (10, 18);cout<<"| |  1.              | |"<<endl;
	gotoxy (10, 19);cout<<"| |  2.              | |"<<endl;
	gotoxy (10, 20);cout<<"| |  3.              | |"<<endl;
	gotoxy (10, 21);cout<<"| |  4.              | |"<<endl;
	gotoxy (10, 22);cout<<"| |  5.              | |"<<endl;
	gotoxy (10, 23);cout<<"| |  6.              | |"<<endl;
	gotoxy (10, 24);cout<<"| |  7.              | |"<<endl;
	gotoxy (10, 25);cout<<"| |  8.              | |"<<endl;
	gotoxy (10, 26);cout<<"| |  9.              | |"<<endl;
	gotoxy (10, 27);cout<<"| |  10.             | |"<<endl;
	gotoxy (10, 28);cout<<"| |__________________| |"<<endl;
	gotoxy (10, 29);cout<<"|______________________|"<<endl;
	
	gotoxy (40, 15); cout<<"  _____________________________________________"<<endl;
	gotoxy (40, 16); cout<<" |  _________________________________________  |"<<endl;
	gotoxy (40, 17);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 18);cout<<" | |     Arrangement in ascending order:     | |"<<endl;
	gotoxy (40, 19);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 20);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 21);cout<<" | |                                         | |"<<endl;;
	gotoxy (40, 22);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (40, 23);cout<<" |_____________________________________________|"<<endl;
	
		
		double d, f;
		double x[9];
	
		int e = 6 , g = 1, h, checker = 0, size;
		string t, o;
		for (int a=0;a<10;a++)
			{
				f = a;
				gotoxy(20,18+f);getline(cin, t);
				size = t.length();
					if (t.empty())
					{
    					gotoxy(52, 20);cout<<"Invalid input!";
						gotoxy(52, 21); system("pause"); system("cls");
						goto main;	
					}
					else if (t == "-0" || t == "+0")
					{
    					gotoxy(52, 20);cout<<"Invalid input!";
						gotoxy(52,21); system("pause"); system("cls");
						goto main;	
					}
					else
					{
						for (int i=0; i<size; i++)
    						{
        						if (isdigit(t[i]) || t[i] == '-' || t[i] == '.' )
            						{checker == 0;}
            					else{checker++;}
            			
            					if (checker != 0)
										{		
    										gotoxy(17, 30);cout<<"Invalid input";
											gotoxy(16,31); system("pause"); system("cls");
											checker = 0;
											goto main;
										}
							
										else
										{
											stringstream change (t);
											change>>x[a];
										}
    								}
							
						
						e++; g++;
					}
			}

	
	for (int b=0;b<9;b++)
	{
		for (int c=0;c<9;c++)
		{
			if (x[c]>x[c+1])
			{
				d = x[c+1];
				x[c+1]=x[c];
				x[c]=d;
			}
		}
	}
	
	
	
	
	for (int a=0;a<10;a++)
	{
		gotoxy (49+(a*3),20); cout<<x[a]<<",";
	}
	
	cout<<endl;
	
	option:
	
	gotoxy (40, 24); cout<<"  _____________________________________________"<<endl;
	gotoxy (40, 25); cout<<" |  _________________________________________  |"<<endl;
	gotoxy (40, 26);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 27);cout<<" | |    Press [1] to try again.              | |"<<endl;
	gotoxy (40, 28);cout<<" | |    Press [0] to exit.                   | |"<<endl;
	gotoxy (40, 29);cout<<" | |    Choice:                              | |"<<endl;
	gotoxy (40, 30);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 31);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 32);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (40, 33);cout<<" |_____________________________________________|"<<endl;
					
		string n; 
		gotoxy(56,29);getline(cin, n);
		size = n.length();
		if (n.empty())
		{
    		gotoxy(47, 30);cout<<"Invalid input!"; 
			gotoxy(47, 31);system ("pause");
			goto option;	
		}
		
		else if (n == "1") 
		{
			system ("cls");
			goto main;
		}
		
		else if ( n == "0") 
		{
			system ("cls");
			gotoxy (20,3);cout<<" _____________________________________________"<<endl;
			gotoxy (20,4);cout<<"|  _________________________________________  |"<<endl;
			gotoxy (20,5);cout<<"| |                                         | |"<<endl;
			gotoxy (20,6);cout<<"| |                                         | |"<<endl;
			gotoxy (20,7);cout<<"| |              THANK YOU :)               | |"<<endl;
			gotoxy (20,8);cout<<"| |                                         | |"<<endl;
			gotoxy (20,9);cout<<"| |  Programmer: Angulo, Michaela Louise S. | |"<<endl;
			gotoxy (20,10);cout<<"| |                                         | |"<<endl;
			gotoxy (20,11);cout<<"| |_________________________________________| |"<<endl;
			gotoxy (20,12);cout<<"|_____________________________________________|"<<endl;
		}
		
		else if (n == "-0" || n == "+0")
		{
    		gotoxy(47, 30);cout<<"Invalid input!";
			gotoxy(47, 31); system("pause");
			goto option;	
		}
		else
		{
    		gotoxy(47, 30);cout<<"Invalid input!";
			gotoxy(47, 31); system("pause");
			goto option;	
		}
}
