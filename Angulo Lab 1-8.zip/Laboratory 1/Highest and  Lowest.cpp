#include <iostream>
#include <windows.h>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
int main()
{
int y, z, f, last = 9, seclast = 8, first = 0, secfirst = 1;
float x[9];
main:
	gotoxy (23, 3); cout<<" ____________________________________________"<<endl;
	gotoxy (23, 4); cout<<"|  ________________________________________  |"<<endl;
	gotoxy (23, 5); cout<<"| |                                        | |"<<endl;
	gotoxy (23, 6); cout<<"| |                                        | |"<<endl;
	gotoxy (23, 7); cout<<"| |          [HIGHEST AND LOWEST]          | |"<<endl;
	gotoxy (23, 8); cout<<"| |                                        | |"<<endl;
	gotoxy (23, 9); cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy (23, 10); cout<<"| |________________________________________| |"<<endl;
	gotoxy (23, 11); cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	gotoxy (0, 14); cout<<"          Enter 10 integer numbers: "<<endl;
	cout<<endl;
	
	gotoxy (10, 15); cout<<" ______________________"<<endl;
	gotoxy (10, 16); cout<<"|  __________________  |"<<endl;
	gotoxy (10, 17);cout<<"| |                  | |"<<endl;
	gotoxy (10, 18);cout<<"| |                  | |"<<endl;
	gotoxy (10, 19);cout<<"| |                  | |"<<endl;
	gotoxy (10, 20);cout<<"| |                  | |"<<endl;
	gotoxy (10, 21);cout<<"| |                  | |"<<endl;
	gotoxy (10, 22);cout<<"| |                  | |"<<endl;
	gotoxy (10, 23);cout<<"| |                  | |"<<endl;
	gotoxy (10, 24);cout<<"| |                  | |"<<endl;
	gotoxy (10, 25);cout<<"| |                  | |"<<endl;
	gotoxy (10, 26);cout<<"| |                  | |"<<endl;
	gotoxy (10, 27);cout<<"| |                  | |"<<endl;
	gotoxy (10, 28);cout<<"| |__________________| |"<<endl;
	gotoxy (10, 29);cout<<"|______________________|"<<endl;
	cout<<""<<endl;
	cout<<""<<endl;
	
	for (int a=0;a<10;a++)
	{
		f = a;
		gotoxy(20,18+f);cin>>x[a];
	}
	cout<<endl;
	cout<<""<<endl;
	cout<<""<<endl;
	cout<<""<<endl;
	
	while(x[z] == x[z + 1])
	{
		++z;
	}
	
	if (z == 9)
	{
	gotoxy (40, 15);cout<<"  _____________________________________________"<<endl;
	gotoxy (40, 16);cout<<" |  _________________________________________  |"<<endl;
	gotoxy (40, 17);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 18);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 19);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 20);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 21);cout<<" | |                                         | |"<<endl;;
	gotoxy (40, 22);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (40, 23);cout<<" |_____________________________________________|"<<endl;
		gotoxy(45,18);cout<<"1st Highest Number: N/A They are equal."<<endl;
		gotoxy(45,19);cout<<"2nd Highest Number: N/A They are equal."<<endl;
		gotoxy(45,20);cout<<"1st Lowest Number: N/A They are equal."<<endl;
		gotoxy(45,21);cout<<"2nd Lowest Number: N/A They are equal."<<endl;
	}
	
	else {
	
	for (int b=0;b<9;b++)
	{
		for (int c=0;c<9;c++)
		{
			if (x[c]>x[c+1])
			{
				y = x[c+1];
				x[c+1]=x[c];
				x[c]=y;
			}
		}	
	}
	gotoxy (40, 15);cout<<"  _____________________________________________"<<endl;
	gotoxy (40, 16);cout<<" |  _________________________________________  |"<<endl;
	gotoxy (40, 17);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 18);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 19);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 20);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 21);cout<<" | |                                         | |"<<endl;;
	gotoxy (40, 22);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (40, 23);cout<<" |_____________________________________________|"<<endl;
	gotoxy(45,18);cout<<"First highest number: " << x[9] << endl;
	while (x[last] == x[seclast])
	{ 
		last--; seclast--;
	}
	
	if (x[9] == x[8])
	{	
		gotoxy(45,19);cout<<"Second highest number: "<<x[seclast]<<endl;
	}
	else
	{
		gotoxy(45,19);cout<<"Second highest number: "<<x[8]<<endl;
	}
	
	gotoxy(45,20);cout<<"First lowest number: " << x[0]<<endl;
	while (x[first] == x[secfirst])
	{
		first++; secfirst++;
	}
	if (x[0] == x[1])
	{
		gotoxy(45,21);cout<<"Second lowest number: "<<x[secfirst]<<endl;
	}
	else
	{
		gotoxy(45,21);cout<<"Second lowest number: "<<x[1]<<endl;
	}
}
	
	gotoxy (40, 25); cout<<"  _____________________________________________"<<endl;
	gotoxy (40, 26); cout<<" |  _________________________________________  |"<<endl;
	gotoxy (40, 27);cout<<" | |                                         | |"<<endl;
	gotoxy (40, 28);cout<<" | |    Press [1] to try again.              | |"<<endl;
	gotoxy (40, 29);cout<<" | |    Press [0] to exit.                   | |"<<endl;
	gotoxy (40, 30);cout<<" | |    Choice:                              | |"<<endl;
	gotoxy (40, 31);cout<<" | |_________________________________________| |"<<endl;
	gotoxy (40, 32);cout<<" |_____________________________________________|"<<endl;
					
		int n; 
		gotoxy(56,30);cin>>n;
		if (n == 1) {
		system ("cls");
		goto main;
		}
		else if ( n == 0) {
		system ("cls");
		}
}
