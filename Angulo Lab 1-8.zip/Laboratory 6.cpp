#include <algorithm>
#include <iostream> // Input and output
#include <string> // String usage
#include <fstream> // Text output (aesthetics)
#include <cmath>
#include <windows.h> // gotoxy() (replica of Turbo C++)
#include <vector>
#include <cstdlib>
#include<ctype.h>
#define MAX 100000

using namespace std;

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void textout(string filename){ // filestreaming text files
	system("cls");
	string line;
	ifstream file;
	file.open(filename.c_str());
	if (file.is_open()) {
		while (getline(file, line)) {
			cout << line << endl;
		}
		file.close();
	}
}

/*void pause(int l){
	//dont ask. i need this as compatibility to linux. hirap na walang windows.
	if (l==0){
		//string s="read -n1 -r -p \"Press any key to continue...\" key";
		system("read -n1 -r -p \"Press any key to continue...\" key");}
	else{
		system("pause");}
}*/






void error(){ // Display message for invalid inputs

	system("cls");
	textout("text\\error.txt");
	system("pause");
}

string tryAgain; // global variable if the user wants to try again

int main(){
    system("color 0a");     // Selection menu
a:	system("mode 104, 35"); // Change console text resolution (W10)
	textout("text\\title.txt");
	gotoxy(52, 13);
	string choice = "";
	string userInputs = "";
	getline(cin, choice); // getline() for accommodating spaces (error handling)

b:	system("cls");
	if (choice == "1"){
        system("cls");
        cout << "Press W/w to write file: ";
        getline(cin, userInputs);


        if(userInputs == "W" || userInputs == "w"){
            FILE *fp;
            cout << endl;
            fp=fopen("text.txt", "w");
            if (!fp){
                cout << "Cannot open file";

            }
            else{
                for(int i=65; i<91;i++){fputc(i,fp);}
                fclose(fp);
                cout << "File written succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

         cout << "Try Again? (y/n): ";
         getline(cin, tryAgain);
         if(tryAgain == "y" || tryAgain == "Y"){
             string userInputs = "";
             goto b;
         }
         else if(tryAgain == "n" || tryAgain == "N"){
             cout << "\nReturning to main menu... "; system("pause"); system("cls");
             goto a;
         }
         else{
             error();
             goto b;
         }

	}
	else if(choice == "2"){
        system("cls");
        cout << "Press R/r to read file: ";
        getline(cin, userInputs);

        if(userInputs == "R" || userInputs == "r"){
            FILE *fp;
            fp=fopen("text.txt", "r");
            if (!fp){
                cout << "Cannot open file";

            }
            else{
                char c;
                cout << "Content of text.txt: \n";
                while((c=fgetc(fp))!=EOF){
                    cout << c;
                }
                cout << endl << endl;
                fclose(fp);

            }
        }

        else{
            error();
            goto b;
        }

        cout << "Try Again? (y/n): ";
        getline(cin, tryAgain);
        if(tryAgain == "y" || tryAgain == "Y"){
             string userInputs = "";
             goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
             cout << "\nReturning to main menu... "; system("pause"); system("cls");
             goto a;
        }
        else{
             error();
             goto b;
        }
	 }

	else if(choice == "3"){
        system("cls");
        cout << "Press A/a to append file: ";
        getline(cin, userInputs);

        if(userInputs == "A" || userInputs == "a"){
            FILE *fp;
            fp=fopen("text.txt", "a");
            if (!fp){
                cout << "Cannot open file";

            }
            else{
                putc('\n',fp);
                for(int i=97; i<123;i++){fputc(i,fp);}
                fclose(fp);
                cout << "File appending succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

       cout << "Try Again? (y/n): ";
       getline(cin, tryAgain);
       if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
       }
       else if(tryAgain == "n" || tryAgain == "N"){
            cout << "\nReturning to main menu... "; system("pause"); system("cls");
            goto a;
       }
       else{
            error();
            goto b;
       }

	}

	else if(choice == "4"){
        system("cls");
        cout << "Press W/w to write file: ";
        getline(cin, userInputs);


        if(userInputs == "W" || userInputs == "w"){
            FILE *fp;
            fp=fopen("text2.txt", "w");
            if (!fp){
                cout << "Cannot open file";
            }
            else{
                fputs("sample string 1\n",fp);
                fputs("sample string 2",fp);
                fclose(fp);
                cout << "File written succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

        cout << "Try Again? (y/n): ";
        getline(cin, tryAgain);

        if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
            cout << "\nReturning to main menu... "; system("pause"); system("cls");
            goto a;
        }
        else{
            error();
            goto b;
        }
	}


    else if(choice == "5"){
        exit(0); // exit program
    }
	else{ // all invalid inputs are error including white spaces
        error();
        goto a;
	}

}





