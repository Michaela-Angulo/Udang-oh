#include<iostream>
#include <windows.h>
using namespace std;
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y); 
void printRow(int x, int y, int z)
{
	for(int i=0;i<=x; i++)
	{
		for(int j=0;j<=y; j++)
		{
			if(i==(x-1) && j==(y-1)){
			gotoXY(2+(i*4),1+(j*2)); cout<<z;
			}
		}
	}	
			gotoXY(0,27);	
}
int main(){
	gotoxy(18,3);cout<<" ____________________________________________"<<endl;
	gotoxy(18,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(18,5);cout<<"| |                                        | |"<<endl;
	gotoxy(18,6);cout<<"| |                                        | |"<<endl;
	gotoxy(18,7);cout<<"| |             [Laboratory 2]             | |"<<endl;
	gotoxy(18,8);cout<<"| |         Arrays with Functions          | |"<<endl;
	gotoxy(18,9);cout<<"| |                                        | |"<<endl;
	gotoxy(18,10);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(18,11);cout<<"| |________________________________________| |"<<endl;
	gotoxy(18,12);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	system("pause");
	system("cls");
	int x,y,z;
	cout<<"-----------------------------------------"<<endl;
	cout<<"| 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
	cout<<"-----------------------------------------"<<endl;
	cout<<"| 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------" <<endl;
    cout<<"| 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------" <<endl;
    cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |"<<endl;
    cout<<"-----------------------------------------"<<endl;
    cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |"<<endl;
    cout<<"-----------------------------------------"<<endl<<endl;
    gotoXY(50,10);cout<<"Enter Column: ";
    gotoXY(70,10);cin>>x;
    gotoXY(50,11);cout<<"Enter Row: "<< endl;
    gotoXY(70,11);cin>>y;
    gotoXY(50,12);cout<<"Enter Number: "<< endl;
    gotoXY(70,12);cin>>z;
	printRow(x,y,z);


}
	                                                                                
void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}

