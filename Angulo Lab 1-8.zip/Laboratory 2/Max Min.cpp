#include<iostream>
#include<cstring>
#include <sstream>
#include<windows.h>
using namespace std;

void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y; 
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
double max (double x, double y)
{
	double ans;
	if (x > y)
	{ans = x;}
	else
	{ans = y;}
	return ans;
}
double min (double x, double y)
{
	double ans;
	if (x < y)
	{ans = x;}
	else
	{ans = y;}
	return ans;
}
int main ()
{
	string a, b, o;
		double am, bm;
		int checker;
		menu:
			cout<<"Enter the first number: ";
	getline(cin, a);
			if (a.empty())
					{
    					cout<<"Invalid input";
						system("pause"); system("cls");
						goto menu;	
					}
			else if (a == "-0" || a == "+0")
					{
						cout<<"Invalid input";
						system("pause"); system("cls");
						goto menu;	
					}
			else
					{
						for (int i=0; i<a.length(); i++)
    						{
        						if (isdigit(a[i]) || a[i] == '-' || a[i] == '.' )
            						{checker == 0;}
            					else{checker++;}
            			
            					if (checker != 0)
										{		
											cout<<"Invalid input";
											system("pause"); system("cls");
											checker = 0;
											goto menu;
										}
							
										else
										{
											stringstream change (a);
											change>>am;
										}
    								}
					}
			cout<<"Enter the second number: ";
			getline(cin, b);
			if (b.empty())
					{
						cout<<"Invalid input";
						gotoxy(16,17); system("pause"); system("cls");
						goto menu;	
					}
			else if (b == "-0" || b == "+0")
					{
						cout<<"Invalid input";
						system("pause"); system("cls");
						goto menu;	
					}
			else
					{
						for (int i=0; i<b.length(); i++)
    						{
        						if (isdigit(b[i]) || b[i] == '-' || b[i] == '.' )
            						{checker == 0;}
            					else{checker++;}
            			
            					if (checker != 0)
										{		
											cout<<"Invalid input";
											system("pause"); system("cls");
											checker = 0;
											goto menu;
										}
							
										else
										{
											stringstream change (b);
											change>>bm;
										}
    								}
					}

option:
if (am == bm){
	cout<<"The numbers are equal";
	}else{cout<<max(am,bm)<<" is greater than "<<min(am,bm);}
	cout<<endl;
	cout<<endl;
	
	cout<<"Press 1 to try again or press 0 to exit"<<endl;
	getline(cin, o);
	 if ( o == "1")
	 {goto menu;}
	 else if( o == "2")
	 {
	 	system("cls");				
	 }
	 else
	 {
	 	cout<<"INVALID INPUT"<<endl;
		system("pause"); 
		goto option;
	 }
	return 0;
		
}
