#include<iostream>
#include<cstring>
#include<windows.h>
#include <sstream>
using namespace std;

int main ()
{
	menu:
		double x, f = 1;
		int a =17 , d = 23,checker = 0;
		string o, number;
		
		cout<<"Enter the number to be converted: ";
		getline(cin,number);
		if (number.empty())
					{
    					cout<<"Invalid input";
						system("pause"); system("cls");
						goto menu;	
					}
		else{
		for (int b=0; b<number.length(); b++)
    				{
        				if (isdigit(number[b]))
            					{checker == 0;}
            			else{checker++;}
    				}
    		if (checker!= 0)
    		{
    			cout<<"Invalid input";
				system("pause"); system("cls");
				goto menu;
			}
			else
			{
				stringstream change (number);
				change>>x;
			}
		}
		
		if ( x >= 0)
    	{
    		for(int i = 1; i <=x; ++i)
    			{
        			f = f * i ;
   				 }
   				 
   				 cout<<x<<"!"<<" is equal to ";
			cout<<f;
			
			cout<<endl;
			cout<<endl;
			
		}
		
		else
		{
			cout<<"Invalid Input"<<endl;
			system("pause");
   			system("cls");
   			goto menu;
		}
		
		option:
		cout<<"Press 1 to try again or press 0 to exit"<<endl;
	getline(cin, o);
	 if ( o == "1")
	 {goto menu;}
	 
	 else if( o == "2")
	 {
	 	system("cls");
	 		 }
	 else
	 {
	 cout<<"INVALID INPUT"<<endl;
	system("pause"); 
		goto option;
	 }
					
		return 0;
}
