#define _USE_MATH_DEFINES
#include <cmath>
#include <windows.h>
#include <iostream>
using namespace std;

void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int main()
{
	main:

	gotoxy (20,3);cout<<" __________________________________________________"<<endl;
	gotoxy (20,4);cout<<"|  ______________________________________________  |"<<endl;
	gotoxy (20,5);cout<<"| |                                              | |"<<endl;
	gotoxy (20,6);cout<<"| |                   Main Menu                  | |"<<endl;
	gotoxy (20,7);cout<<"| |                                              | |"<<endl;
	gotoxy (20,8);cout<<"| |----------------------------------------------| |"<<endl;
	gotoxy (20,9);cout<<"| |                                              | |"<<endl;
	gotoxy (20,10);cout<<"| |Press [1] for finding the area of a square    | |"<<endl;
	gotoxy (20,11);cout<<"| |Press [2] for finding the area of a rectangle | |"<<endl;
	gotoxy (20,12);cout<<"| |Press [3] for finding the area of a triangle  | |"<<endl;
	gotoxy (20,13);cout<<"| |Press [4] for finding the area of a circle    | |"<<endl;
	gotoxy (20,14);cout<<"| |Press [5] to QUIT                             | |"<<endl;
	gotoxy (20,15);cout<<"| |                                              | |"<<endl;
	gotoxy (20,16);cout<<"| |Choice:                                       | |"<<endl;
	gotoxy (20,17);cout<<"| |______________________________________________| |"<<endl;
	gotoxy (20,18);cout<<"|__________________________________________________|"<<endl;
	cout<<""<<endl;
	int x;
	gotoxy(31,16);cin>>x;cout<<endl;  
	system ("cls");
	
	if ( x > 5 ) {
 	gotoxy (20, 3); cout<<"  _____________________________________________"<<endl;
 	gotoxy (20, 4); cout<<" |  _________________________________________  |"<<endl;
 	gotoxy (20, 5);cout<<" | |                                         | |"<<endl;
 	gotoxy (20, 6);cout<<" | |             Invalid input!              | |"<<endl;
 	gotoxy (20, 7);cout<<" | |_________________________________________| |"<<endl;
 	gotoxy (20, 8);cout<<" |_____________________________________________|"<<endl;
 
 	gotoxy (29, 10);cout<<"  ___________________________"<<endl;
 	gotoxy (29, 11);cout<<" |  _______________________  |"<<endl;
 	gotoxy (29, 12);cout<<" | |                       | |"<<endl;
 	gotoxy (29, 13);cout<<" | |Press [1] to try again.| |"<<endl;
  	gotoxy (29, 14);cout<<" | |Press [0] to exit.     | |"<<endl;
 	gotoxy (29, 15);cout<<" | |Choice:                | |"<<endl;
 	gotoxy (29, 16);cout<<" | |_______________________| |"<<endl;
 	gotoxy (29, 17);cout<<" |___________________________|"<<endl;
					
		int y; 
		gotoxy(69,12);cin>>y;
		if (y == 1) {
		system ("cls");
		goto main;
		}
		else if ( y == 0) {
		system ("cls");
		}
	}
	else if ( x <= 0 ){
 	gotoxy (20, 3);cout<<"  _____________________________________________"<<endl;
 	gotoxy (20, 4);cout<<" |  _________________________________________  |"<<endl;
 	gotoxy (20, 5);cout<<" | |                                         | |"<<endl;
 	gotoxy (20, 6);cout<<" | |             Invalid input!              | |"<<endl;
 	gotoxy (20, 7);cout<<" | |_________________________________________| |"<<endl;
 	gotoxy (20, 8);cout<<" |_____________________________________________|"<<endl;
 
 	gotoxy (29, 10);cout<<"  ___________________________"<<endl;
 	gotoxy (29, 11);cout<<" |  _______________________  |"<<endl;
 	gotoxy (29, 12);cout<<" | |                       | |"<<endl;
 	gotoxy (29, 13);cout<<" | |Press [1] to try again.| |"<<endl;
  	gotoxy (29, 14);cout<<" | |Press [0] to exit.     | |"<<endl;
 	gotoxy (29, 15);cout<<" | |Choice:                | |"<<endl;
 	gotoxy (29, 16);cout<<" | |_______________________| |"<<endl;
 	gotoxy (29, 17);cout<<" |___________________________|"<<endl;
					
		int y; 
		gotoxy(69,12);cin>>y;
		if (y == 1) {
		system ("cls");
		goto main;
		}
		else if ( y == 0) {
		system ("cls");
		}
	}
	
	else {

switch(x){
	
	case 1:
		{
		numbawan:
		
			float a,s;
			gotoxy(0,3);cout<<" _____________________________________________"<<endl;
		  	gotoxy(0,4);cout<<"|  _________________________________________  |"<<endl;
			gotoxy(0,5);cout<<"| |                                         | |"<<endl;
			gotoxy(0,6);cout<<"| |Enter the value of the side of the square| |"<<endl;
			gotoxy(0,7);cout<<"| |_________________________________________| |"<<endl;
			gotoxy(0,8);cout<<"|_____________________________________________|"<<endl;
			cout<<""<<endl;
			gotoxy(10,10);cout<<" _____________________"<<endl;
			gotoxy(10,11);cout<<"|                     |"<<endl;
			gotoxy(10,12);cout<<"|                     |"<<endl;
			gotoxy(10,13);cout<<"|                     |"<<endl;
			gotoxy(10,14);cout<<"|                     |"<<endl;
			gotoxy(10,15);cout<<"|                     |"<<endl;
			gotoxy(10,16);cout<<"|                     |   x = "<<endl;
			gotoxy(10,17);cout<<"|                     |"<<endl;
			gotoxy(10,18);cout<<"|                     |"<<endl;
			gotoxy(10,19);cout<<"|                     |"<<endl;
			gotoxy(10,20);cout<<"|                     |"<<endl;
			gotoxy(10,21);cout<<"|_____________________|"<<endl;
			gotoxy(40,16);cin>>s;
			
			if (s == 0) {
			gotoxy(0, 23);cout<<"    The side value of the square is required!"<<endl;
			
			gotoxy (50, 12);cout<<"  _________________________________"<<endl;
			gotoxy (50, 13);cout<<" |  _____________________________  |"<<endl;
			gotoxy (50, 14);cout<<" | |                             | |"<<endl;
			gotoxy (50, 15);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (50, 16);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (50, 17);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (50, 18);cout<<" | |_____________________________| |"<<endl;
			gotoxy (50, 19);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(62,17);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbawan;
			}
			
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
	
			else if (s < 0) {
			gotoxy(0, 23);cout<<"The side value of a square cannot be negative!"<<endl;
			gotoxy (50, 12);cout<<"  _________________________________"<<endl;
			gotoxy (50, 13);cout<<" |  _____________________________  |"<<endl;
			gotoxy (50, 14);cout<<" | |                             | |"<<endl;
			gotoxy (50, 15);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (50, 16);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (50, 17);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (50, 18);cout<<" | |_____________________________| |"<<endl;
			gotoxy (50, 19);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(62,17);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbawan;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else {
			a = s*s;	
			gotoxy(0, 23);cout<<"       Area of the square: ";cout<<a;cout<<" sq. units"<<endl;
			gotoxy (50, 12);cout<<"  _________________________________"<<endl;
			gotoxy (50, 13);cout<<" |  _____________________________  |"<<endl;
			gotoxy (50, 14);cout<<" | |                             | |"<<endl;
			gotoxy (50, 15);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (50, 16);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (50, 17);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (50, 18);cout<<" | |_____________________________| |"<<endl;
			gotoxy (50, 19);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(62,17);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbawan;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
		}
	case 2: 
		{
		numbatu:
		
			float a,l,w;
			gotoxy(0,3);cout<<" _________________________________________________"<<endl;
			gotoxy(0,4);cout<<"|  _____________________________________________  |"<<endl;
			gotoxy(0,5);cout<<"| |                                             | |"<<endl;
			gotoxy(0,6);cout<<"| | Enter the length and width of the rectangle | |"<<endl;
			gotoxy(0,7);cout<<"| |_____________________________________________| |"<<endl;
			gotoxy(0,8);cout<<"|_________________________________________________|"<<endl;
			cout<<endl;
			gotoxy(10,10);cout<<" _____________________"<<endl;
			gotoxy(10,11);cout<<"|                     |"<<endl;
			gotoxy(10,12);cout<<"|                     |"<<endl;
			gotoxy(10,13);cout<<"|                     |  l = "<<endl;
			gotoxy(10,14);cout<<"|                     |"<<endl;
			gotoxy(10,15);cout<<"|_____________________|"<<endl;
			gotoxy(10,17);cout<<"          w =         "<<endl;
			gotoxy(40,13);cin>>l;
			gotoxy(25,17);cin>>w;
			
			if (l == 0 && w == 0) {
			gotoxy(2, 19);cout<<"    The value of length and width are required!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (l < 0 && w < 0) {
			gotoxy(2, 19);cout<<"The value of length and width cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (l < 0) {
			gotoxy(2, 19);cout<<"The value of length cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (l == 0) {
			gotoxy(2, 19);cout<<"The value of length cannot be equal to zero!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (w < 0) {
			gotoxy(2, 19);cout<<"The value of width cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (w == 0) {
			gotoxy(2, 19);cout<<"The value of width cannot be equal to zero!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (w == l) {
			gotoxy(2, 19);cout<<"The sides of a rectangle cannot be equal!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else {
			a = l*w;
			gotoxy(0, 20);cout<<"     Area of the rectangle: ";cout<<a;cout<<" sq. units"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatu;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
		}
	case 3:
		{
		numbatri:
		
			float a,b,h;
			gotoxy(0,3);cout<<" _____________________________________________"<<endl;
			gotoxy(0,4);cout<<"|  _________________________________________  |"<<endl;
			gotoxy(0,5);cout<<"| |                                         | |"<<endl;
			gotoxy(0,6);cout<<"| |Enter the base and height of the triangle| |"<<endl;
			gotoxy(0,7);cout<<"| |_________________________________________| |"<<endl;
			gotoxy(0,8);cout<<"|_____________________________________________|"<<endl;
			cout<<""<<endl;
			gotoxy(13,10);cout<<"         |*"<<endl;
			gotoxy(13,11);cout<<"         | *                    "<<endl;
			gotoxy(13,12);cout<<"         |  *                   "<<endl;
			gotoxy(13,13);cout<<"         |   *                  "<<endl;
			gotoxy(13,14);cout<<"         |    *                 "<<endl;
			gotoxy(13,15);cout<<"         |     *                "<<endl;
			gotoxy(13,16);cout<<"h =      |      *               "<<endl;
			gotoxy(13,17);cout<<"         |       *              "<<endl;
			gotoxy(13,18);cout<<"         |        *             "<<endl;
			gotoxy(13,19);cout<<"         |         *            "<<endl;
			gotoxy(13,20);cout<<"         |          *           "<<endl;
			gotoxy(13,21);cout<<"         |___________*"<<endl;
			gotoxy(13,23);cout<<"             b =   "<<endl;
			gotoxy(17,16);cin>>h;
			gotoxy(30,23);cin>>b;
			
			if (h == 0 && b == 0) {
			gotoxy(2, 25);cout<<"    The value of base and height are required!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (b < 0 && h < 0) {
			gotoxy(2, 25);cout<<"The value of base and height cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (b == 0) {
			gotoxy(2, 19);cout<<"The value of base cannot be equal to zero!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (b < 0) {
			gotoxy(2, 19);cout<<"The value of base cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (h == 0) {
			gotoxy(2, 19);cout<<"The value of height cannot be equal to zero!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (h < 0) {
			gotoxy(2, 19);cout<<"The value of height cannot be negative!"<<endl;
			gotoxy (56, 10);cout<<"  _________________________________"<<endl;
			gotoxy (56, 11);cout<<" |  _____________________________  |"<<endl;
			gotoxy (56, 12);cout<<" | |                             | |"<<endl;
			gotoxy (56, 13);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (56, 14);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (56, 15);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (56, 16);cout<<" | |_____________________________| |"<<endl;
			gotoxy (56, 17);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(68,15);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else {
			a = b*h/2;
			gotoxy(0, 25);cout<<"       Area of the triangle: ";cout<<a;cout<<" sq. units"<<endl;
			gotoxy (50, 12);cout<<"  _________________________________"<<endl;
			gotoxy (50, 13);cout<<" |  _____________________________  |"<<endl;
			gotoxy (50, 14);cout<<" | |                             | |"<<endl;
			gotoxy (50, 15);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (50, 16);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (50, 17);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (50, 18);cout<<" | |_____________________________| |"<<endl;
			gotoxy (50, 19);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(62,17);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbatri;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
		}
	case 4:
		{
		numbafor:
		
			float a,r;
			gotoxy(20,3);cout<<" _____________________________________________"<<endl;
			gotoxy(20,4);cout<<"|  _________________________________________  |"<<endl;
			gotoxy(20,5);cout<<"| |                                         | |"<<endl;
			gotoxy(20,6);cout<<"| |     Enter the radius of the circle:     | |"<<endl;
			gotoxy(20,7);cout<<"| |                                         | |"<<endl;
			gotoxy(20,8);cout<<"| |                                         | |"<<endl;
			gotoxy(20,9);cout<<"| |                                         | |"<<endl;
			gotoxy(20,10);cout<<"| |                                         | |"<<endl;
			gotoxy(20,11);cout<<"| |                                         | |"<<endl;
			gotoxy(20,12);cout<<"| |                                         | |"<<endl;
			gotoxy(20,13);cout<<"| |_________________________________________| |"<<endl;
			gotoxy(20,14);cout<<"|_____________________________________________|"<<endl;
			cout<<""<<endl;
			gotoxy(41,8);cin>>r;
			
			if (r == 0) {
			gotoxy(23, 10);cout<<"  The radius of the circle is required!"<<endl;
			
			gotoxy (25, 16);cout<<"  _________________________________"<<endl;
			gotoxy (25, 17);cout<<" |  _____________________________  |"<<endl;
			gotoxy (25, 18);cout<<" | |                             | |"<<endl;
			gotoxy (25, 19);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (25, 20);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (25, 21);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (25, 22);cout<<" | |_____________________________| |"<<endl;
			gotoxy (25, 23);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(36,21);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbafor;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else if (r < 0) {
			gotoxy(23, 10);cout<<"  The radius of the circle is required!"<<endl;
			
			gotoxy (25, 16);cout<<"  _________________________________"<<endl;
			gotoxy (25, 17);cout<<" |  _____________________________  |"<<endl;
			gotoxy (25, 18);cout<<" | |                             | |"<<endl;
			gotoxy (25, 19);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (25, 20);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (25, 21);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (25, 22);cout<<" | |_____________________________| |"<<endl;
			gotoxy (25, 23);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(36,21);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbafor;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
			
			else {
			a = M_PI * r * r;
			gotoxy(23, 10);cout<<"       The area of the circle is: "<<endl;
			gotoxy(35, 12);cout<<a<<" sq. units"<<endl;
			cout<<endl;
			cout<<endl;
			cout<<endl;
			cout<<endl;
			
			gotoxy (25, 16);cout<<"  _________________________________"<<endl;
			gotoxy (25, 17);cout<<" |  _____________________________  |"<<endl;
			gotoxy (25, 18);cout<<" | |                             | |"<<endl;
			gotoxy (25, 19);cout<<" | |Press [1] to try again.      | |"<<endl;
			gotoxy (25, 20);cout<<" | |Press [0] to go back to main.| |"<<endl;
			gotoxy (25, 21);cout<<" | |Choice:                      | |"<<endl;
			gotoxy (25, 22);cout<<" | |_____________________________| |"<<endl;
			gotoxy (25, 23);cout<<" |_________________________________|"<<endl;
						
			int y; 
			gotoxy(36,21);cin>>y;
			if (y == 1) {
			system ("cls");
			goto numbafor;
			}
			else if ( y == 0) {
			system ("cls");
			goto main;
			}
			}
		}
		
	case 5: 
	{
	gotoxy (20,3);cout<<" _____________________________________________"<<endl;
	gotoxy (20,4);cout<<"|  _________________________________________  |"<<endl;
	gotoxy (20,5);cout<<"| |                                         | |"<<endl;
	gotoxy (20,6);cout<<"| |                                         | |"<<endl;
	gotoxy (20,7);cout<<"| |              THANK YOU :)               | |"<<endl;
	gotoxy (20,8);cout<<"| |                                         | |"<<endl;
	gotoxy (20,9);cout<<"| |  Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy (20,10);cout<<"| |                                         | |"<<endl;
	gotoxy (20,11);cout<<"| |_________________________________________| |"<<endl;
	gotoxy (20,12);cout<<"|_____________________________________________|"<<endl;
	}
	}
}
}
