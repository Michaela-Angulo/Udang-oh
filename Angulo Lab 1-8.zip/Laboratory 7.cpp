#include  <iostream>
#include <windows.h>
#include <sstream>
using namespace  std; 
void gotoxy (int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
struct Item
{
	int code;
	char name [50]; 
	double price;
};

void displayitem (Item* &itm) ; 
void newline() ;

int main ()
{
	gotoxy(18,3);cout<<" ____________________________________________"<<endl;
	gotoxy(18,4);cout<<"|  ________________________________________  |"<<endl;
	gotoxy(18,5);cout<<"| |                                        | |"<<endl;
	gotoxy(18,6);cout<<"| |                                        | |"<<endl;
	gotoxy(18,7);cout<<"| |             [Laboratory 7]             | |"<<endl;
	gotoxy(18,8);cout<<"| |         Structures and Pointers        | |"<<endl;
	gotoxy(18,9);cout<<"| |                                        | |"<<endl;
	gotoxy(18,10);cout<<"| | Programmer: Angulo, Michaela Louise S. | |"<<endl;
	gotoxy(18,11);cout<<"| |________________________________________| |"<<endl;
	gotoxy(18,12);cout<<"|____________________________________________|"<<endl;
	cout<<""<<endl;
	system("pause");
	system("cls");
	Item* itm;
	itm = new Item;
	cout << "Enter Item Information: \n"; 
	cout << "Code: ";
	cin >> itm->code;
	newline();
	cout << "Name: " ;
	cin.getline (itm->name, 49);
	cout << "Price : ";
	cin >> itm->price;
	displayitem(itm);
	system("pause>0");

	return 0;
}

void displayitem (Item* &itm)
{
	cout << "\n\nDisplay Item  Information :\n"; 
	cout << "Code : " << itm->code <<  endl;
	cout << "Name : " << itm->name  << endl;
	cout << "Price: " << itm->price  << endl;
}

void newline()
{
	char s;
	do{
		cin.get(s);
	} while(s != '\n');
	
}

